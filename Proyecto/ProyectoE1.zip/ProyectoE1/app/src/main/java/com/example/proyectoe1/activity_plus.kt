package com.example.proyectoe1

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class activity_plus : AppCompatActivity() {

    private var pictureIV : ImageView? =null
    private lateinit var photoFile: File
    lateinit var currentPhotoPath: String
    private val PICTURE_FROM_CAMERA: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plus)



        initViews()
        registerListener()
    }

    private fun initViews(){
        pictureIV=findViewById<ImageView>(R.id.Picture)
    }
    private fun registerListener() {
        pictureIV!!.setOnClickListener {
            takePicture()
        }
    }

    private fun takePicture() {
        val pictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        photoFile = createImageFile()
        val uri = FileProvider.getUriForFile(
            this@activity_plus,
            "com.example.retrofittest.fileprovider",
            photoFile
        )
        pictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        startActivityForResult(pictureIntent, PICTURE_FROM_CAMERA)
    }

    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir)
            .apply { currentPhotoPath = absolutePath }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode== Activity.RESULT_OK) {
            if (requestCode== PICTURE_FROM_CAMERA){
                val uri= FileProvider.getUriForFile(this,"com.example.retrofittest.fileprovider",photoFile)
                pictureIV!!.setImageURI(uri)
            }
        }
        else
            super.onActivityResult(requestCode, resultCode, data)
    }
}